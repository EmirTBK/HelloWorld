namespace HelloWorld {
    class HelloWorld {
        static void Main(string[] args) {
            System.Console.WriteLine("Hello World!");
        }
    }
}
